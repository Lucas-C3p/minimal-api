namespace MinimalApi.Dominio.Enuns;

public enum Perfil
{
    Adm,
    Editor
}